# Agenda-Contactos
Agenda de contatos en java

Funciones de la agenda:

-Añadir, modificar y eliminar ocntactos.
-clasificar contactos con etiquetas
-Crear y borrar las etiquetas
-Visualiazar contactos y etiquetas
-Buscar contactos mediante telefono o nombre


INSTRUCIONES DE USO

Importar la base de datos en xampp/wampp, en la importacion dara error al crear el
usaurio que usaremos para manejar la base de datos (para evitar usar root ). Para estar seguros de 
que el usario este creado en la base de datos vamos al apartado de privilegios y comporvamos que halla un usuario
llamado "ConexionAgenda". En caso dee estar creado compilar y ejecutar el programa.

-En caso de error con la libreria Jcalendar
    Solucion: en las dependencias elegimos la dependencia de jcalendar y la instalamso manualmente.
