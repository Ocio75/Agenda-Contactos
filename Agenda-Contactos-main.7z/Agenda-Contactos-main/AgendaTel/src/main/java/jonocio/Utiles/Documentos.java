package jonocio.Utiles;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import jonocio.BBDD.*;
import java.io.File;
import java.io.FileOutputStream;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JFileChooser;

public class Documentos extends Conexion{
    Select select = new Select();
   

    public void hacerPdf() throws DocumentException, SQLException {
        LocalDate now = LocalDate.now();
        int year = now.getYear();
        int dia = now.getDayOfMonth();
        int month = now.getMonthValue();
        String fechaFormateada = String.format("%02d%02d%d", dia, month, year);

        LocalTime localTime = LocalTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HHmmss");
        String horaFormateada = localTime.format(formatter);

        try {
            Document documento = new Document();
            String rutaSalida = System.getProperty("user.home") + "/Documents/Infromes_Agenda"; // Carpeta de salida de los archivos PDF
            File carpeta = new File(rutaSalida);
            if (!carpeta.exists()) {
                carpeta.mkdir(); // Crea la carpeta si no existe
            }

            String salida = "Informe_Agenda_Contactos_" + fechaFormateada + "_" + horaFormateada + ".pdf";
            PdfWriter writer = PdfWriter.getInstance(documento, new FileOutputStream(rutaSalida + "/" + salida));

            // Agregar evento de pie de página
            writer.setPageEvent(new PdfPageEventHelper() {
                public void onEndPage(PdfWriter writer, Document document) {
                    PdfContentByte canvas = writer.getDirectContent();
                    Phrase pageNumber = new Phrase("Página " + writer.getPageNumber());
                    ColumnText.showTextAligned(canvas, Element.ALIGN_CENTER, pageNumber,
                            (document.right() + document.left()) / 2,
                            document.bottom() - 20, 0);
                }
            });

            documento.open();

            Font fontTitulo = new Font(Font.FontFamily.HELVETICA, 20);
            Paragraph titulo = new Paragraph("INFORME AGENDA", fontTitulo);
            titulo.setAlignment(Element.ALIGN_CENTER);
            titulo.setSpacingAfter(20); // Espacio después del título
            documento.add(titulo);

            documento.add(new Paragraph("En la agenda hay " + select.contatContactos() + " contactos"));

            Conectar();
            String sql = "SELECT c.id, c.nombre, c.apellidos, c.telefono, c.correo, c.direccion, c.genero, c.fecha_nacimiento, c.notas, t.nombre AS nombre_tipo FROM contactos c, tipocontacto t WHERE c.idTipocon = t.id ORDER BY c.id";

            Statement st;
            try {
                st = con.createStatement();
                ResultSet rs = st.executeQuery(sql);

                while (rs.next()) {
                    String informacion = "\n " + rs.getString(2) + " " + rs.getString(3)
                            + "\n\t    - Telefono: " + rs.getString(4)
                            + "\n\t    - Correo electronico: " + rs.getString(5)
                            + "\n\t    - Direccion: " + rs.getString(6)
                            + "\n\t    - Genero: " + rs.getString(7)
                            + "\n\t    - Fecha nacimineto: " + rs.getString(8)
                            + "\n\t    - Notas: " + rs.getString(9)
                            + "\n\t    - Etiqueta: " + rs.getString(10);

                    Paragraph informacionParrafo = new Paragraph(informacion);
                    informacionParrafo.setSpacingAfter(10); // Espacio después de cada bloque de información
                    informacionParrafo.setMultipliedLeading(1.5f); // Espacio entre líneas
                    informacionParrafo.setKeepTogether(true); // Evita que se divida en dos páginas
                    documento.add(informacionParrafo);
                }
            } catch (SQLException ex) {
                MensaEmergentes.alerta(2, "Error al cargar datos" + ex, "Error");
            }

            Cerrar();
            documento.close();
            MensaEmergentes.alerta(1, "Documento creado correctamente", "Informacion");
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Documentos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     public void hacerPdfPersonalizado() throws DocumentException, SQLException {
        JFileChooser seleccionar = new JFileChooser();
        Document documento = new Document();

        if (seleccionar.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
            File archivo = seleccionar.getSelectedFile();
            if (archivo.getName().endsWith("pdf")) {
                try {
                    String rutaSalida = archivo.getAbsolutePath();

                    // Agregar extensión .pdf si no está presente en el nombre del archivo
                    if (!rutaSalida.toLowerCase().endsWith(".pdf")) {
                        rutaSalida += ".pdf";
                    }

                    PdfWriter writer = PdfWriter.getInstance(documento, new FileOutputStream(rutaSalida));

                    // Agregar evento de pie de página
                    writer.setPageEvent(new PdfPageEventHelper() {
                        public void onEndPage(PdfWriter writer, Document document) {
                            PdfContentByte canvas = writer.getDirectContent();
                            Phrase pageNumber = new Phrase("Página " + writer.getPageNumber());
                            ColumnText.showTextAligned(canvas, Element.ALIGN_CENTER, pageNumber,
                                    (document.right() + document.left()) / 2,
                                    document.bottom() - 20, 0);
                        }
                    });

                    documento.open();

                    Font fontTitulo = new Font(Font.FontFamily.HELVETICA, 20);
                    Paragraph titulo = new Paragraph("INFORME AGENDA", fontTitulo);
                    titulo.setAlignment(Element.ALIGN_CENTER);
                    titulo.setSpacingAfter(20); // Espacio después del título
                    documento.add(titulo);

                    documento.add(new Paragraph("En la agenda hay " + select.contatContactos() + " contactos"));

                    Conectar();
                    String sql = "SELECT c.id, c.nombre, c.apellidos, c.telefono, c.correo, c.direccion, c.genero, c.fecha_nacimiento, c.notas, t.nombre AS nombre_tipo FROM contactos c, tipocontacto t WHERE c.idTipocon = t.id ORDER BY c.id";

                    Statement st;
                    try {
                        st = con.createStatement();
                        ResultSet rs = st.executeQuery(sql);

                        while (rs.next()) {
                            String informacion = "\n " + rs.getString(2) + " " + rs.getString(3)
                                    + "\n\t    - Telefono: " + rs.getString(4)
                                    + "\n\t    - Correo electronico: " + rs.getString(5)
                                    + "\n\t    - Direccion: " + rs.getString(6)
                                    + "\n\t    - Genero: " + rs.getString(7)
                                    + "\n\t    - Fecha nacimineto: " + rs.getString(8)
                                    + "\n\t    - Notas: " + rs.getString(9)
                                    + "\n\t    - Etiqueta: " + rs.getString(10);

                            Paragraph informacionParrafo = new Paragraph(informacion);
                            informacionParrafo.setSpacingAfter(10); // Espacio después de cada bloque de información
                            informacionParrafo.setMultipliedLeading(1.5f); // Espacio entre líneas
                            informacionParrafo.setKeepTogether(true); // Evita que se divida en dos páginas
                            documento.add(informacionParrafo);
                        }
                    } catch (SQLException ex) {
                        MensaEmergentes.alerta(2, "Error al cargar datos" + ex, "Error");
                    }

                    Cerrar();
                    documento.close();
                    MensaEmergentes.alerta(1, "Documento creado correctamente", "Informacion");
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(Documentos.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }


   /* public void hacerPdf() throws DocumentException, SQLException{
        LocalDate now = LocalDate.now();
        int year = now.getYear();
        int dia = now.getDayOfMonth();
        int month = now.getMonthValue();
        String fechaFormateada = String.format("%02d%02d%d", dia, month, year);
        try {
            Document documento = new Document();
            String rutaSalida = System.getProperty("user.home");
            String salida ="Informe_Agenda_Contactos_"+fechaFormateada+".pdf";
            PdfWriter.getInstance(documento, new FileOutputStream(rutaSalida+"/Documents/"+salida));
            documento.open();
            Font fontTitulo = new Font(Font.FontFamily.HELVETICA, 20);
            Paragraph titulo = new Paragraph("INFORME AGENDA", fontTitulo);
            titulo.setAlignment(Element.ALIGN_CENTER);
            documento.add(titulo);
            documento.add(new Paragraph(" "));
            documento.add(new Paragraph(" "));
            documento.add(new Paragraph("En la agenda hay "+select.contatContactos()+" contactos"));
            
            Conectar();
            String sql = "SELECT c.id, c.nombre, c.apellidos, c.telefono, c.correo, c.direccion, c.genero, c.fecha_nacimiento, c.notas, t.nombre AS nombre_tipo FROM contactos c, tipocontacto t WHERE c.idTipocon = t.id ORDER BY c.id";
            
            Statement st;
            try {
                st = con.createStatement();
                ResultSet rs = st.executeQuery(sql);
                while (rs.next()) {
                   String Informacion="\n "+ rs.getString(2)+ " "+rs.getString(3)+
                           "\n\t    -Telefono: "+rs.getString(4)+"\n\t    -Correo electronico: "+rs.getString(5)+
                           "\n\t    -Direccion: "+rs.getString(6)+"\n\t    -Genero "+rs.getString(7)+
                           "\n\t    -Fecha nacimineto: "+rs.getString(8)+"\n\t    -Notas: "+rs.getString(9)+"\n\t    -Etiqueta: "+rs.getString(10); 
                   documento.add(new Paragraph(Informacion));
                }

            } catch (SQLException ex) {
                MensaEmergentes.alerta(2, "Error al cargar datos" + ex, "Error");
            }
        
            
        
            Cerrar();
            documento.close();
            MensaEmergentes.alerta(1, "Documento creado correctamente ", "Informacion");
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Documentos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }*/
    /*
    
    public void hacerPdf() throws DocumentException{
       
        try {
            Document documento = new Document();
            String salida ="Informe_Agenda_Contactos.pdf";
            PdfWriter.getInstance(documento, new FileOutputStream(salida));
            documento.open();
                 
        
        
            documento.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Documentos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    */
}
