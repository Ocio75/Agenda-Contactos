
package jonocio.AgendaTel;

import java.sql.SQLException;


public class AAbase {

    public static void main(String[] args) throws SQLException {
        Principal p1 =new Principal();
        p1.setVisible(true);
    }
}
